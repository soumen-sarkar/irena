$(window).load(function(){
	   
	//Script for nav button animation	
    $(".navbar-toggle").on('click', function(){
      $(this).toggleClass("active");
    });
    
    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });
    
    //Script of owl-carousel
	var owl = $("#owl-demo");	
	owl.owlCarousel({
		autoPlay : 3000,
		items : 2,
        itemsDesktop : [990, 1],
        itemsDesktopSmall : [767, 4],
        itemsTablet : [560, 3],
        itemsTabletSmall : [479, 2],
        itemsMobile : [370, 1],	
	});
    
	
});